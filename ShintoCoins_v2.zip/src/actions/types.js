export const BUY_SHINTO_COIN = "Buy-Shinto-Coin";
export const MINE_SHINTO_COIN = "Mine-Shinto-Coin";
export const SELL_SHINTO_COIN = "Sell-Shinto-Coin";
